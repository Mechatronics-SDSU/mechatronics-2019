import numpy as np
import cv2
import socket
import sys
import io
import csv

HOST    = '127.0.0.101'
ADDRESS = 5558

OURSOCKET = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

OURSOCKET.bind((HOST, ADDRESS))

#cap = cv2.VideoCapture(0)

ramBuffer = b''

while(True):

    # Socket Max receive

    packet = OURSOCKET.recv(1024)


    print(packet)
    ramBuffer= ramBuffer+packet

#    print('packet Written Status: ', status)


    if packet[-1]==67:
        #Capture Bytes
        img_frame = cv2.imdecode(np.frombuffer(ramBuffer, dtype=np.uint8), -10)
        #ret, img_frame = cv2.imdecode('.jpg', ramBuffer)

    # Our operations on the frame come here

        gray = cv2.cvtColor(img_frame, cv2.COLOR_BGR2GRAY)

    # Display the resulting frame
        cv2.imshow( 'frame', gray )
        cv2.waitKey()

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

# When everything done, release the capture
cap.release()
cv2.destroyAllWindows()


