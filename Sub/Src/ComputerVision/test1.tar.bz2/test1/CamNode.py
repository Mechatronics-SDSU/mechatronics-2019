import numpy as np
import cv2
import socket
import sys
import struct
import math
import io

HOST    = '127.0.0.101'
ADDRESS = 5558
MAX_UDP_PACKET_SIZE = 1024


OURSOCKET=socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
cap = cv2.VideoCapture(0)

while(True):
    # Capture frame-by-frame
    ret, frame = cap.read()

    # print('NO imencode',sys.getsizeof(frame))
    # Capture Bytes
    ret, byte_frame = cv2.imencode( '.jpg', frame )

    # print('YES imencode', sys.getsizeof(byte_frame))
    # Our operations on the frame come here

#    byte_frame = struct.pack('=%sf' % byte_frame.size, *byte_frame)

    # Get the Size of the image
    image_size = sys.getsizeof(byte_frame)

    # Max Byte Size

    if image_size >= MAX_UDP_PACKET_SIZE:

        imageBuffer = io.BytesIO(byte_frame)

        number_of_packets = math.ceil(image_size/MAX_UDP_PACKET_SIZE)

        packet_size = math.ceil(image_size/number_of_packets)

        for packet_size in range(1,number_of_packets):

            OURSOCKET.sendto(imageBuffer.read(packet_size), (HOST, ADDRESS))
            #print(imageBuffer.read(packet_size))
        imageBuffer.seek(0)

    else:
        OURSOCKET.sendto(byte_frame, (HOST, ADDRESS))



# When everything done, release the capture
cap.release()
cv2.destroyAllWindows()
